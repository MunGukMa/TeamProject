create table fit_gamelist(
gamename varchar2(20) primary key,
gamelevel number,
pclevel number,
imagelink varchar2(100) not null,
gamecpu varchar2(50),
gameram varchar2(50),
gamegpu varchar2(50),
gameaddop varchar2(100),
memo varchar2(100));

create table fit_cpu (
num number primary key,
cpuname varchar2(100) not null,
cpucode varchar2(100) not null,
cores varchar2(100) not null,
clock varchar2(100) not null,
socket varchar2(100) not null,
process varchar2(100) not null,
l3cache varchar2(100) not null,
tdp varchar2(100) not null,
released varchar2(100) not null,
point number default null);

create table fit_case(
num number primary key,
casename varchar2(100),
rowprice varchar2(20),
power varchar2(50),
mainboardsize varchar2(100),
casesize varchar2(100),
addop varchar2(600));

create table fit_gpu (
num number primary key,
manufacturer varchar2(10) not null,
product_name varchar2(50) not null,
chip varchar2(20) not null,
realeased_date varchar2(20) not null,
bus varchar2(20) not null,
m_size varchar2(20) not null,
m_ddr varchar2(20) not null,
m_bit varchar2(20) not null,
g_clock varchar2(20) not null,
m_clock varchar2(20) not null,
tdp varchar2(20) not null,
rank number not null
); 

create table fit_ram (
num number primary key,
name varchar2(100) not null,
spec varchar2(300) not null,
src_link varchar2(300) not null
);

create table fit_mainboard
(
    num number primary key,
    name varchar2(100) not null,
    sockets varchar2(100) not null,
    formFactor varchar2(100) not null,
    chipSet varchar2(100) not null,
    RAM varchar2(50) not null,
    releaseDate varchar2(50) not null,
    audioChip varchar2(50) not null,
    usb2 varchar2(20) not null,
    usb3 varchar2(20) not null,
    sata varchar2(20) not null
);

create table fit_power
(
    num number primary key,
    name varchar2(200) not null,
    price varchar2(20),
    power varchar2(20) ,
    output varchar2(20) not null,
    fanSize varchar2(20),
    fanNum varchar2(10),
    atx varchar2(10),
    sata varchar2(10),
    connecter varchar2(200),
    etc varchar2(500),
    releaseDate varchar2(20)
);

create table fit_steam
(
    num number primary key,
    appid varchar2(100) not null,
    name varchar2(200) not null
);

create table fit_member(
    fit_userid varchar2(20) primary key,
    fit_userpwd varchar2(20) not null,
    fit_usernick varchar2(20) not null,
    fit_usermail varchar2(50) not null,
    fit_userkeyvalue varchar2(50) not null,
    fit_userestimatenum varchar2(50)
);

create table fit_board(
    fit_boardnum number primary key,
    fit_userid varchar2(20) not null,
    fit_boardtitle varchar2(50) not null,
    fit_pcsets varchar2(30),
    fit_boardcontent varchar2(200),
    fit_boarddate date default sysdate,
    fit_boardhit number default 0
);


create sequence fit_board_seq;


create table fit_comment(
fit_commentnum number primary key,
fit_boardnum number not null,
fit_userid varchar2(20) not null,
fit_comments varchar2(100) not null,
fit_commentdate date default sysdate
);

create sequence fit_comment_seq;

create table fit_pcestimate(
    fit_pcnum number primary key,
    fit_userid varchar2(20) not null,
    fit_cpuname varchar2(100),
    fit_casename varchar2(100),
    fit_gpuname varchar2(100),
    fit_mainboardname varchar2(100),
    fit_powername varchar2(100),
    fit_ramname varchar2(100)
);

create sequence fit_pcestimate_seq;



insert into FIT_GAMELIST values('overwatch',5,5,'resources/icon/overwatch.jpg','Intel I5 8500','16gb','GTX 1060','nope',null);

insert into FIT_GAMELIST values('battleground',6,4,'resources/icon/playerunknowns_battlegrounds.jpg','Intel I3 7500','8gb','GTX 1050','nope',null);

insert into FIT_GAMELIST values('dota2',2,3,'resources/icon/dota_2.jpg','Intel I7 9900','16gb','GTX 2080','nope',null);

insert into FIT_GAMELIST values('wow',7,1,'resources/icon/world_of_warcraft.jpg','Intel I5 8500','16gb','GTX 1060','nope',null);

insert into FIT_GAMELIST values('rainbow6',4,5,'resources/icon/tom_clancys_rainbow_six_siege.jpg','Intel I5 8500','16gb','GTX 1060','nope',null);
