package team.project.one.dao;

import java.util.ArrayList;
import java.util.HashMap;

public interface AutoMapper {


	ArrayList<String> getlist(HashMap<String, String> templist);

}
